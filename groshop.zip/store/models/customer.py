from django.db import models


class Customer(models.Model):
    fname = models.CharField(max_length=30)
    lname = models.CharField(max_length=30)
    email=models.EmailField(max_length=30,default=None)
    phone = models.CharField(max_length=30)
    password = models.CharField(max_length=30)

    def __str__(self):
        return self.fname

    @staticmethod
    def get_customer_byEmail(phone):
        try:
            return Customer.objects.get(phone=phone)
        except:
            return False

    def isExist(self):
        if Customer.objects.filter(email=self.email):
            return True
        return False
    def isExistphone(self):
        if Customer.objects.filter(phone=self.phone):
            return True
        return False

    def register(self):
        return self.save()

