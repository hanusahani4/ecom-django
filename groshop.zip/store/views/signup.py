from django.shortcuts import render, redirect

from store.models import Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postdata = request.POST
        fname = postdata.get('fname')
        lname = postdata.get('lname')
        email = postdata.get('email')
        phone = postdata.get('phone')
        password = postdata.get('password')

        value = {
            'fname': fname,
            'lname': lname,
            'phone': phone,
        }
        customer = Customer(fname=fname, lname=lname, email=email, phone=phone, password=password)

        error_message = None
        error_message = self.validateCustomer(customer)

        if not error_message:

            customer.password = make_password(customer.password)

            customer.register()
            return redirect('login')

        else:
            data = {
                'error_message': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None
        if not customer.fname:
            error_message = "first name is required"


        elif customer.isExist():
            error_message = " email already Exist"

        elif customer.isExistphone():
            error_message = 'phone already exist'
        elif not customer.phone:
            error_message = "please enter phone number"

        return error_message
